## Pràctica final RA - Part anais

En aquesta carpeta hi ha una subcarpeta amb el paquet que hem utilitzat:

- `robot_final`: És el paquet de catkin que conté tots els arxius necessaris, de tal forma que només s'ha de copiar a la carpeta `catkin_ws/src` i fer un `catkin_make` des de la carpeta `catkin_ws` per compilar-lo. El paquet conté:
  - `src`: Conté els codis en cpp que es convertiran en executables.
  - `scripts`: Conté els codis en python. Això és degut a que hem fet part del codi en python i part en cpp.
  - `launch`: Conté l'arxiu de llançament que permet executar tot el projecte amb una sola comanda.
  - `maps`: Conté el mapa que utilitza el robot en format `.yaml` i `.pgm`.
  - `CMakeLists.txt` i `package.xml`: Són els arxius necessaris per a la compilació del paquet de catkin.

També hem intentat pujar tots els vídeos, però ocupaven massa i no ha estat possible. A continuació es troba un enllaç per accedir a tots els vídeos: https://drive.google.com/drive/folders/1MqxIiVjceP4MPk1HFfDYBI-MnhkZOlae?usp=drive_link

I ara l'explicació de cada un d'ells:

- **creacio_mapa**: En aquest video es pot veure com creem el mapa movent el robot amb el teleop.
- **deteccio_colors**: Aquí es visualitza com el robot reconeix les diferents boles de colors, i publica el color corresponent per pantalla.
- **exemple_visita_cases**: Es pot observar com el robot va a diferents cases per veure si hi ha una pilota, però en aquesta cas no hi ha pilotes en l'espai. Per tant, el robot es mou de casa en casa ininterrompudament, ja que si no veu brossa el robot va visitant cases aleatòries (amb restricció de no anar a la casa justament anterior).
- **exemple_deteccio_moviment1**: En aquest altre es veu exemple on el robot detecta una bola groga amb la càmera, i va fins la posició del contenidor corresponent (no es veu el contenidor al terra perquè no l'haviem posat, però és la posició correcta).
- **exemple_deteccio_moviment2**: Igual que l'anterior però ara es pot veure el contenidor al terra.
- **exemple_manipulacio_gazebo**: Aquí visualitzem un exemple de pick i place en simulació.
- **exemple_manipulacio_real**: En aquest cas es pot veure un exemple de pick i place en el robot real.
- **exemple_deteccio_manipulacio_moviment**: Finalment, aquí afegim la funcionalitat del braç robòtic, i quan es detecta una pilota, el braç s'aixeca perquè nosaltres coloquem la pilota. Després va al contenidor, i la deixa. Per realitzar aquesta prova vam tenir molt poc temps, ja que necessitavem un robot que li funciones el braç i la càmera alhora. Això va provocar que no canviéssim el nom del topic de la camèra del node de visió. Per tant, no reconeixia les boles i vam enviar-li a mà al tòpic que havia detectat una pilota (sabent d'altres proves que la detecció de colors es fa bé). Sense voler, li vam enviar a mà el color erroni i, per això, deixa la pilota blava al contenidor groc, però l'objectiu del vídeo era comprovar que funcionava el braç.