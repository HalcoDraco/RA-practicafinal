import socket
import time
import xml.etree.ElementTree as ET
import os

# ───────────────────────────────────
# PARÀMETRES 
# ───────────────────────────────────
HOST = "10.10.73.239"      # IP del robot (s'ha de canviar)
PORT = 30002               # Port (sempre és el mateix)
XML_FILE = "taskfile_tampconfig_prueba.xml" # Fitxer XML que el vol passar al robot real 

# Scripts per tancar i obrir pinça (estan a Atenea)
CERRAR_PINZA = "pinza10UR3.py"  
ABRIR_PINZA  = "pinza40UR3.py" 

ACC = 0.5   # Acceleració 
VEL = 0.5   # Velocitat   
DWELL = 2   # Pausa entre enviament de configuracions al robot

# ───────────────────────────────────
# FUNCIONS AUXILIARS
# ───────────────────────────────────
def parse_paths(xml_path):
    """Retorna una llista de blocs {'type': 'Transit'|'Transfer', 'data': [[q1..q6], ...]}."""
    tree = ET.parse(xml_path)
    task = tree.getroot()
    blocks = []

    for elem in task:
        if elem.tag not in ("Transit", "Transfer"):
            continue

        path = []
        for conf in elem.findall("Conf"):
            values = list(map(float, conf.text.strip().split()))
            # Els joints del UR3 són els valors 8-13 (índexs 7-12) :contentReference[oaicite:0]{index=0}
            path.append(values[7:13])

        blocks.append({"type": elem.tag, "data": path})

    return blocks


def send_joint_path(path, sock, acc=ACC, vel=VEL, dwell=DWELL):
    """Envia una llista de configuracions articulares al robot amb movej()."""
    for q in path:
        cmd = f"movej({q}, a={acc}, v={vel})\n"
        sock.send(cmd.encode())
        print("Enviat:", q)
        time.sleep(dwell)


def send_script(script_file, sock):
    """Envia un fitxer .py amb les ordres de la pinça via socket."""
    with open(script_file, "rb") as f:
        sock.sendall(f.read())
    print("Script enviat:", script_file)
    time.sleep(1)


# ───────────────────────────────────
# EXECUCIÓ PRINCIPAL
# ───────────────────────────────────
def main():
    # 1) Parsejar l’arxiu XML
    blocks = parse_paths(XML_FILE)
    print(f"S'han trobat {len(blocks)} blocs de trajectòria al TaskFile.")

    # 2) Obrir socket amb la controladora UR
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((HOST, PORT))

    try:
        # En primer lloc, obrir la pinça
        send_script(ABRIR_PINZA, sock)
        for blk in blocks:
            if blk["type"] == "Transit":
                # Moviment “lliure” (sense objecte)
                send_joint_path(blk["data"], sock)

            elif blk["type"] == "Transfer":
                # PICK – abans de moure, tancar pinça
                send_script(CERRAR_PINZA, sock)

                # Trasllat amb l’objecte agafat
                send_joint_path(blk["data"], sock)

                # PLACE – un cop arribat, obrir pinça
                send_script(ABRIR_PINZA, sock)

        print("Trajectòria completada correctament.")

    finally:
        sock.close()


if __name__ == "__main__":
    main()
