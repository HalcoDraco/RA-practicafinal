import numpy as np

def normalize_degrees_to_unit_interval(degree_angles):
    """
    Convierte una lista de ángulos en grados a:
    1. Intervalo [-180, 180]
    2. Intervalo [-pi, pi]
    3. Intervalo [0, 1]
    """
    result = []

    for deg in degree_angles:
        # Paso 1: llevarlo a [-180, 180]
        deg_wrapped = ((deg + 180) % 360) - 180

        # Paso 2: convertir a radianes en [-pi, pi]
        rad = np.deg2rad(deg_wrapped)

        # Paso 3: escalar de [-pi, pi] a [0, 1]
        normalized = (rad + np.pi) / (2 * np.pi)

        result.append({
            "original_deg": deg,
            "wrapped_deg": deg_wrapped,
            "rad": rad,
            "normalized": normalized
        })

    return result

# Grados a convertir
grados = [6.64, -118.59, -66.66, -88.77, 94.13, 10.29]

# Conversión
resultado = normalize_degrees_to_unit_interval(grados)

# Imprimir detalles por ángulo
for r in resultado:
    print(f"{r['original_deg']:>6}° -> {r['wrapped_deg']:>6}° -> {r['rad']:+.3f} rad -> normalizado: {r['normalized']:.3f}")

# Imprimir línea con los valores normalizados finales
print("\nValores normalizados:")
print(' '.join(f"{r['normalized']:.6f}" for r in resultado))
