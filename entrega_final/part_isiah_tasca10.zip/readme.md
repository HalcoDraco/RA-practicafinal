## Pràctica final RA - Part Isiah

En aquesta carpeta s'han entregat tots els arxius utilitzats al llarg del projecte. A continuació s'expliquen breument:

- `UR3e`: En aquest directori trobem tots els arxius que han sigut necessaris per obtenir la solució final. Inclou els arxius `PDDL`, el **xml** del `Kautham`, el `tampconfig` i el `taskfile`. Finalment també hi ha la carpeta de controls.

- `robot_real`: En aquesta carpeta es troben tots els arxius necessaris per fer l'execució de la solució en el robot final. Inclou els dos scripts per obrir i tancar la pinça (`pinza10UR3.py` i `pinza40UR3.py`), el **taskfile** que conté la solució final i l'arxiu `UR3.py`, que és un codi que, donats els dos scripts comentats anteriorment i el **taskfile**, envia al robot real tots els moviments de la solució.

- `altres`: Finalment, en aquesta carpeta trobem dos arxius que també s'han utilitzat durant el projecte. El primer, `nuestro_launch.launch.py`, s'ha utilitzat per executar el client que es conecta a **kautham** i **ROS** per generar la solució final. I el segon, `grad_to_rad.py`, és un codi auxiliar que hem utilitzat per a transformar posicions en l'espai de configuracions del robot real, que es donen en graus, al format necessari pels arxius **.xml**, radiants normalitzades entre 0 i 1. 

Finalment, també hem gravat un video demostració en el robot real, però no l'hem pogut pujar degut a la seva mida. En el següent enllaç el podeu trobar: https://drive.google.com/drive/folders/1bfkZUMpemHtLgVSm-TBssegKR_ZlQIv0?usp=drive_link